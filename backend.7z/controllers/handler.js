'use strict';
const dbcon = require('./../utils/db');
const QUERIES = require('./sql');
const httpUtil = require('./../utils/HttpUtil');

/* 
    signup /auth/signup route to create new user.
*/
exports.edit = async (req, res, next) => {
	try {
		let reqData = req.body;
		reqData.user_agent = JSON.stringify(req.useragent);
		let user = await dbcon.query(QUERIES.USER_CHECK, reqData.oAuth_user_id);
		if (user.length === 0) {
			reqData.register_date = moment().format('DD/MM/YYYY hh:mm:a');
			reqData.user_agent = JSON.stringify(req.useragent);
			await dbcon.query(QUERIES.ADD_USER, reqData);
			let addedUser = await dbcon.query(QUERIES.USER_CHECK, reqData.oAuth_user_id);
			let permissions = {
				user_id: addedUser[0].id,
				is_pro_user: 'no',
				is_pro_upload: 'no',
				is_data_sync: 'no',
				is_profile_edit: 'yes',
			};
			await dbcon.query(QUERIES.ADD_PERMISSION, permissions);
			let uid = cryptoJS.AES.encrypt(String(addedUser[0].id), ENCRYPTION_KEY).toString();
			res.json(httpUtil.getSuccess(uid));
		} else {
			let uid = cryptoJS.AES.encrypt(String(user[0].id), ENCRYPTION_KEY).toString();
			res.json(httpUtil.getSuccess(uid));
		}
	} catch (error) {
		console.log(error, 'from error');
		res.json(httpUtil.getException('Sign Up Error', null, error));
	}
};

exports.Save = async (req, res, next) => {
	try {
		console.log(req.body);
		let data = {
			options: JSON.stringify(req.body.choices),
			question: req.body.question,
		};
		await dbcon.query(QUERIES.ADD_QUSEIONS, data);
		res.json(httpUtil.getSuccess(req.body));
	} catch (error) {
		console.log(error);
		res.json(httpUtil.getException(error, 'Exception Caught', 5001));
	}
};

exports.getAll = async (req, res, next) => {
	try {
		let dbData = await dbcon.query(QUERIES.GET_DATA);
		res.json(httpUtil.getSuccess(dbData));
	} catch (error) {
		res.json(httpUtil.getException(error, 'Exception Caught', 5001));
	}
};
