'use strict';

module.exports = {
	ADD_QUSEIONS: 'INSERT INTO tbl_test set ?',
	GET_DATA: '	select * from tbl_test',
};
