'use strict';

module.exports = {
	ROOT_API: '/api',
	SAVE: '/save',
	EDIT: '/edit',
};
